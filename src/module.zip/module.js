var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
const dragonIgnoreArr = [
  "Amethyst",
  "Black",
  "Blue",
  "Brass",
  "Bronze",
  "Copper",
  "Crystal",
  "Deep",
  "Emerald",
  "Gold",
  "Green",
  "Lunar",
  "Moonstone",
  "Red",
  "Sapphire",
  "Silver",
  "Solar",
  "Topaz",
  "White"
];
const currencyMap = /* @__PURE__ */ new Map([
  ["Copper", "cp"],
  ["Silver", "sp"],
  ["Electrum", "ep"],
  ["Gold", "gp"],
  ["Platinum", "pp"]
]);
const sizeHashMap = /* @__PURE__ */ new Map([
  ["tiny", 5],
  ["sm", 5],
  ["med", 5],
  ["lg", 11],
  ["huge", 14.2],
  ["grg", 17.7]
]);
const skillMap = /* @__PURE__ */ new Map([
  ["Acrobatics", "acr"],
  ["Animal Handling", "ani"],
  ["Arcana", "arc"],
  ["Athletics", "ath"],
  ["Deception", "dec"],
  ["History", "his"],
  ["Insight", "ins"],
  ["Investigation", "inv"],
  ["Intimidation", "itm"],
  ["Medicine", "med"],
  ["Nature", "nat"],
  ["Persuasion", "per"],
  ["Perception", "prc"],
  ["Performance", "prf"],
  ["Religion", "rel"],
  ["Sleight of Hand", "slt"],
  ["Stealth", "ste"],
  ["Survival", "sur"]
]);
const CONSTANTS = {
  MODULE_ID: "harvester",
  SOURCE_REFERENCE_MODULE: "Harvester",
  harvestActionId: "ich3SV1HXRlq8K32",
  harvestActionEffectId: "0plmpCQ8D2Ezc1Do",
  harvestActionEffectName: "Harvested",
  harvestActionEffectIcon: "icons/svg/pawprint.svg",
  lootActionId: "yaMtYJlcLh9mSBQI",
  lootActionEffectId: "KiM9NV0Od4a27JmY",
  lootActionEffectName: "Looted",
  lootActionEffectIcon: "icons/svg/coins.svg",
  actionCompendiumId: "harvester.actions",
  harvestCompendiumId: "harvester.harvest",
  lootCompendiumId: "harvester.loot",
  customCompendiumId: "harvester.custom",
  customLootCompendiumId: "harvester.custom-loot",
  betterRollTableId: "better-rolltables.brt-harvest-harvester",
  dragonIgnoreArr,
  currencyMap,
  sizeHashMap,
  currencyMap,
  skillMap
};
function registerSettings() {
  game.settings.register(CONSTANTS.MODULE_ID, "autoAddItems", {
    name: "Automatically Assign Items",
    hint: "All harvested loot and looted currency is added to characters automatically.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: true
  });
  game.settings.register(CONSTANTS.MODULE_ID, "autoAddItemPiles", {
    name: "Automatically Assign Items to Item Piles",
    hint: "All harvested loot and looted currency is added to Item Piles.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: true
  });
  game.settings.register(CONSTANTS.MODULE_ID, "autoAddActionGroup", {
    name: "Automatically Assign Action",
    hint: "Gives the Actions to the selected group.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: String,
    choices: {
      All: "All Characters",
      PCOnly: "Player Characters Only",
      None: "None"
    },
    default: "PCOnly"
  });
  game.settings.register(CONSTANTS.MODULE_ID, "npcOnlyHarvest", {
    name: "NPC Only Harvesting",
    hint: "Only non player characters can be looted/harvested.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: true
  });
  game.settings.register(CONSTANTS.MODULE_ID, "requireDeadEffect", {
    name: "Dead Effect Required",
    hint: "Requires the 'Dead' status effect to Harvest/Loot. (Otherwise only needs 0 HP)",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: true
  });
  game.settings.register(CONSTANTS.MODULE_ID, "gmOnly", {
    name: "Other players cannot see results",
    hint: "Hides the Results from all other users except the GM",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enforceRange", {
    name: "Enforce Action Range",
    hint: "Force users to be in range to be able to use Harvest/Loot.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: true
  });
  game.settings.register(CONSTANTS.MODULE_ID, "allowAbilityChange", {
    name: "Allow ability score change on roll",
    hint: "Used if DM's trust their players and/or wish to use a different ability score instead of the default without making a custom compendium entry",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "disableLoot", {
    name: "Disable Looting mechanic",
    hint: "Disables the Loot mechanic, making it unavailable until enabled.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "lootBeasts", {
    name: "Loot All Creatures",
    hint: "Allow looting of all possible creatures including beasts",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "enableBetterRollIntegration", {
    name: "Enable integration with the module 'Better Rolltable'",
    hint: "Integration with the module 'Better Rolltable', for a more randomized behavior during the harvester action and a better customization for the specific creature, formula, filter additional elements, etc.",
    scope: "world",
    config: true,
    requiresReload: true,
    type: Boolean,
    default: false
  });
  game.settings.register(CONSTANTS.MODULE_ID, "debug", {
    name: "Enable debugging",
    hint: "Prints debug messages to the console",
    scope: "client",
    config: true,
    default: false,
    type: Boolean
  });
  SETTINGS.autoAddItems = game.settings.get(CONSTANTS.MODULE_ID, "autoAddItems");
  SETTINGS.autoAddItemPiles = game.settings.get(CONSTANTS.MODULE_ID, "autoAddItemPiles");
  SETTINGS.autoAddItems = game.settings.get(CONSTANTS.MODULE_ID, "autoAddItems");
  SETTINGS.gmOnly = game.settings.get(CONSTANTS.MODULE_ID, "gmOnly");
  SETTINGS.requireDeadEffect = game.settings.get(CONSTANTS.MODULE_ID, "requireDeadEffect");
  SETTINGS.npcOnlyHarvest = game.settings.get(CONSTANTS.MODULE_ID, "npcOnlyHarvest");
  SETTINGS.autoAddActionGroup = game.settings.get(CONSTANTS.MODULE_ID, "autoAddActionGroup");
  SETTINGS.enforceRange = game.settings.get(CONSTANTS.MODULE_ID, "enforceRange");
  SETTINGS.allowAbilityChange = game.settings.get(CONSTANTS.MODULE_ID, "allowAbilityChange");
  SETTINGS.disableLoot = game.settings.get(CONSTANTS.MODULE_ID, "disableLoot");
  SETTINGS.lootBeasts = game.settings.get(CONSTANTS.MODULE_ID, "lootBeasts");
  SETTINGS.enableBetterRollIntegration = game.settings.get(CONSTANTS.MODULE_ID, "enableBetterRollIntegration");
  SETTINGS.debug = game.settings.get(CONSTANTS.MODULE_ID, "debug");
}
__name(registerSettings, "registerSettings");
const SETTINGS = {
  autoAddItems: true,
  autoAddItemPiles: true,
  gmOnly: false,
  requireDeadEffect: true,
  npcOnlyHarvest: true,
  autoAddActionGroup: "PCOnly",
  enforceRange: true,
  allowAbilityChange: false,
  disableLoot: false,
  lootBeasts: false,
  enableBetterRollIntegration: false
};
const _RequestorHelpers = class _RequestorHelpers {
  /*
    await Requestor.request({
        img: "icons/creatures/abilities/dragon-breath-purple.webp",
        title: "Test d'un test !",
        description: "C'est un test d'un test, pour tester quoi.",
        popout: true,
        autoclose: false,
        speaker: ChatMessage.getSpeaker({actor: token.actor}),
        whisper: ChatMessage.getWhisperRecipients("David"),
        sound: "ressources/assets/audio/Special/Toast.mp3",
        buttonData: [{
            label: "A Skill Check",
            limit: Requestor.LIMIT.ONCE,
            permission: Requestor.PERMISSION.ALL ,
            command: async function(){
            await Requestor.diceRoll({formula: "2d4+2", flavor: "Healing Potion"});
            },
            scope: {skill: "nat"}
        }],
        messageOptions: {
            speaker: ChatMessage.getSpeaker({actor: token.actor}),
        },
    });
    */
  static async requestRollSkill(actorUseForRequest, tokenUseForRequest, chatDetails = {
    chatTitle: "",
    chatDescription: "",
    chatButtonLabel: "",
    chatWhisper: void 0,
    chatSpeaker: void 0,
    chatImg: void 0
  }, skillDetails = {
    skillDenomination: "",
    skillItem: {},
    skillCallback: function() {
    },
    skillChooseModifier: false
  }, optionsRequestor = {
    limit: _RequestorHelpers.LIMIT.ONCE,
    permission: _RequestorHelpers.PERMISSION.ALL
  }) {
    const { chatTitle, chatDescription, chatButtonLabel, chatWhisper, chatSpeaker, chatImg } = chatDetails;
    const { skillDenomination, skillItem, skillCallback, skillChooseModifier } = skillDetails;
    const { limit, permission } = optionsRequestor;
    const actorSpeaker = tokenUseForRequest?.actor ? tokenUseForRequest.actor : actorUseForRequest;
    const rollObj = await Requestor.request({
      img: chatImg,
      title: chatTitle ?? "This is a request title.",
      description: chatDescription ?? "This is a request description.",
      popout: true,
      autoclose: true,
      speaker: chatSpeaker ?? ChatMessage.getSpeaker({ actor: actorSpeaker }),
      whisper: chatWhisper ?? ChatMessage.getWhisperRecipients(actorSpeaker.name),
      buttonData: chatButtonLabel ? [
        {
          label: chatButtonLabel,
          limit,
          permission,
          command: async function() {
            const roll = await actor.rollSkill(skillDenomination, {
              skillChooseModifier
            });
            const options = {
              token,
              character,
              actor,
              event,
              data: this,
              roll,
              skillDenomination,
              item: skillItem
            };
            await game.modules.get(moduleId).api[skillCallback](options);
          },
          scope: {
            moduleId: CONSTANTS.MODULE_ID,
            skillDenomination,
            skillCallback,
            skillItem,
            skillChooseModifier
          },
          messageOptions: {
            speaker: ChatMessage.getSpeaker({ actor: actorSpeaker })
          }
        }
      ] : []
    });
    return rollObj;
  }
  static async requestEmptyMessage(actorUseForRequest, tokenUseForRequest, chatDetails = {
    chatTitle: "",
    chatDescription: "",
    chatButtonLabel: "",
    chatWhisper: void 0,
    chatSpeaker: void 0,
    chatImg: void 0
  }) {
    const { chatTitle, chatDescription, chatButtonLabel, chatWhisper, chatSpeaker, chatImg } = chatDetails;
    const actorSpeaker = token?.actor ? token.actor : actorUseForRequest;
    const rollObj = await Requestor.request({
      img: chatImg,
      title: chatTitle ?? "This is a request title.",
      description: chatDescription ?? "This is a request description.",
      popout: true,
      autoclose: true,
      speaker: chatSpeaker ?? ChatMessage.getSpeaker({ actor: actorSpeaker }),
      whisper: chatWhisper ?? ChatMessage.getWhisperRecipients(actorSpeaker.name)
    });
    return rollObj;
  }
};
__name(_RequestorHelpers, "RequestorHelpers");
__publicField(_RequestorHelpers, "LIMIT", {
  FREE: 0,
  ONCE: 1,
  OPTION: 2
});
// Who can view the button.
__publicField(_RequestorHelpers, "PERMISSION", {
  ALL: 0,
  GM: 1,
  PLAYER: 2
});
__publicField(_RequestorHelpers, "TRUST_OPTIONS", {
  GM: 0,
  OWN: 1,
  FREE: 2
});
let RequestorHelpers = _RequestorHelpers;
const _Logger = class _Logger {
  static get DEBUG() {
    return game.settings.get(CONSTANTS.MODULE_ID, "debug") || game.modules.get("_dev-mode")?.api?.getPackageDebugValue(CONSTANTS.MODULE_ID, "boolean");
  }
  // export let debugEnabled = 0;
  // 0 = none, warnings = 1, debug = 2, all = 3
  static debug(msg, ...args) {
    try {
      if (game.settings.get(CONSTANTS.MODULE_ID, "debug") || game.modules.get("_dev-mode")?.api?.getPackageDebugValue(CONSTANTS.MODULE_ID, "boolean")) {
        console.log(`DEBUG | ${CONSTANTS.MODULE_ID} | ${msg}`, ...args);
      }
    } catch (e) {
      console.error(e.message);
    }
    return msg;
  }
  static logObject(...args) {
    return this.log("", args);
  }
  static log(message, ...args) {
    try {
      message = `${CONSTANTS.MODULE_ID} | ${message}`;
      console.log(message.replace("<br>", "\n"), ...args);
    } catch (e) {
      console.error(e.message);
    }
    return message;
  }
  static notify(message, ...args) {
    try {
      message = `${CONSTANTS.MODULE_ID} | ${message}`;
      ui.notifications?.notify(message);
      console.log(message.replace("<br>", "\n"), ...args);
    } catch (e) {
      console.error(e.message);
    }
    return message;
  }
  static info(info, notify = false, ...args) {
    try {
      info = `${CONSTANTS.MODULE_ID} | ${info}`;
      if (notify) {
        ui.notifications?.info(info);
      }
      console.log(info.replace("<br>", "\n"), ...args);
    } catch (e) {
      console.error(e.message);
    }
    return info;
  }
  static warn(warning, notify = false, ...args) {
    try {
      warning = `${CONSTANTS.MODULE_ID} | ${warning}`;
      if (notify) {
        ui.notifications?.warn(warning);
      }
      console.warn(warning.replace("<br>", "\n"), ...args);
    } catch (e) {
      console.error(e.message);
    }
    return warning;
  }
  static errorObject(...args) {
    return this.error("", false, args);
  }
  static error(error, notify = true, ...args) {
    try {
      error = `${CONSTANTS.MODULE_ID} | ${error}`;
      if (notify) {
        ui.notifications?.error(error);
      }
      console.error(error.replace("<br>", "\n"), ...args);
    } catch (e) {
      console.error(e.message);
    }
    return new Error(error.replace("<br>", "\n"));
  }
  static errorPermanent(error, notify = true, ...args) {
    try {
      error = `${CONSTANTS.MODULE_ID} | ${error}`;
      if (notify) {
        ui.notifications?.error(error, {
          permanent: true
        });
      }
      console.error(error.replace("<br>", "\n"), ...args);
    } catch (e) {
      console.error(e.message);
    }
    return new Error(error.replace("<br>", "\n"));
  }
  static timelog(message) {
    this.warn(Date.now(), message);
  }
  // setDebugLevel = (debugText): void => {
  //   debugEnabled = { none: 0, warn: 1, debug: 2, all: 3 }[debugText] || 0;
  //   // 0 = none, warnings = 1, debug = 2, all = 3
  //   if (debugEnabled >= 3) CONFIG.debug.hooks = true;
  // };
  static dialogWarning(message, icon = "fas fa-exclamation-triangle") {
    return `<p class="${CONSTANTS.MODULE_ID}-dialog">
        <i style="font-size:3rem;" class="${icon}"></i><br><br>
        <strong style="font-size:1.2rem;">${CONSTANTS.MODULE_ID}</strong>
        <br><br>${message}
    </p>`;
  }
};
__name(_Logger, "Logger");
__publicField(_Logger, "i18n", (key) => {
  return game.i18n.localize(key)?.trim();
});
__publicField(_Logger, "i18nFormat", (key, data = {}) => {
  return game.i18n.format(key, data)?.trim();
});
let Logger = _Logger;
function checkItemSourceLabel(item, sourceLabel) {
  if (item.system.source?.label === sourceLabel) {
    return true;
  }
  if (item.system.source?.custom === sourceLabel) {
    return true;
  }
  return false;
}
__name(checkItemSourceLabel, "checkItemSourceLabel");
function retrieveItemSourceLabelDC(item) {
  let itemDC = void 0;
  itemDC = item.system.source?.label.match(/\d+/g)[0];
  if (!itemDC || item.system.source?.custom) {
    itemDC = item.system.source?.custom?.match(/\d+/g)[0];
  }
  return itemDC ?? 0;
}
__name(retrieveItemSourceLabelDC, "retrieveItemSourceLabelDC");
const _HarvestingHelpers = class _HarvestingHelpers {
  static async handlePreRollHarvestAction(options) {
    const { item } = options;
    if (!checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
      return;
    }
    let targetedToken = canvas.tokens.get(getProperty(item, `flags.${CONSTANTS.MODULE_ID}.targetId`)) ?? game.user.targets.first();
    let targetedActor = game.actors.get(targetedToken.actor?.id ?? targetedToken.document?.actorId);
    let controlledToken = canvas.tokens.get(getProperty(item, `flags.${CONSTANTS.MODULE_ID}.controlId`)) ?? canvas.tokens.controlled[0];
    game.actors.get(controlledToken.actor?.id ?? controlledToken.document?.actorId);
    let matchedItems = [];
    if (SETTINGS.enableBetterRollIntegration && hasBetterRollTables) {
      matchedItems = _HarvestingHelpers.retrieveTablesHarvestWithBetterRollTables(
        targetedActor,
        harvestAction.name || item.name
      );
    } else {
      matchedItems = searchCompendium(targetedActor, harvestAction.name || item.name);
    }
    let skillDenomination = getProperty(item, `flags.${CONSTANTS.MODULE_ID}.skillCheck`);
    let skillCheck = "Nature";
    if (matchedItems.length === 0) {
      RequestorHelpers.requestEmptyMessage(controlledToken.actor, void 0, {
        chatTitle: "Harvesting valuable from corpses.",
        chatDescription: `<h3>Looting</h3><ul>'${controlledToken.name}' attempted to loot resources from '${targetedToken.name}' but failed to find anything for this creature.`,
        chatButtonLabel: void 0,
        chatWhisper: void 0,
        chatSpeaker: void 0,
        chatImg: "icons/skills/social/theft-pickpocket-bribery-brown.webp"
      });
    } else {
      let skillCheckVerbose;
      let harvestMessage = targetedToken.name;
      if (harvestMessage !== targetedActor.name) {
        harvestMessage += ` (${targetedActor.name})`;
      }
      if (SETTINGS.enableBetterRollIntegration && hasBetterRollTables) {
        skillCheckVerbose = getProperty(matchedItems[0], `flags.better-rolltables.brt-skill-value`);
        skillCheck = skillCheckVerbose;
      } else {
        if (matchedItems[0].compendium.metadata.id === CONSTANTS.harvestCompendiumId) {
          if (matchedItems[0]?.system?.unidentified?.description) {
            skillCheckVerbose = matchedItems[0]?.system.unidentified.description;
          } else {
            skillCheckVerbose = matchedItems[0]?.system.description.unidentified;
          }
        } else {
          skillCheckVerbose = matchedItems[0].items.find((element) => element.type === "feat").name;
        }
        skillCheck = CONSTANTS.skillMap.get(skillCheckVerbose);
      }
      item.setFlag(CONSTANTS.MODULE_ID, "skillCheck", skillCheck);
      item.update({ system: { formula: `1d20 + @skills.${skillCheck}.total` } });
      RequestorHelpers.requestRollSkill(
        controlledToken.actor,
        void 0,
        {
          chatTitle: `Harvesting Skill Check (${skillDenomination})`,
          chatDescription: `<h3>Harvesting</h3><ul>'${controlledToken.name}' attempted to harvest resources from '${targetedToken.name}'.`,
          chatButtonLabel: `Attempting to Harvest ${harvestMessage}`,
          chatWhisper: void 0,
          chatSpeaker: void 0,
          chatImg: "icons/tools/cooking/knife-cleaver-steel-grey.webp"
        },
        {
          skillDenomination,
          skillItem: item,
          skillCallback: "handlePostRollHarvestAction",
          skillChooseModifier: SETTINGS.allowAbilityChange
        }
      );
    }
    item.setFlag(CONSTANTS.MODULE_ID, "targetId", "");
  }
  static async handlePostRollHarvestAction(options) {
    const { actor: actor2, item, roll } = options;
    if (!checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
      return;
    }
    let targetedToken = canvas.tokens.get(getProperty(item, `flags.${CONSTANTS.MODULE_ID}.targetId`)) ?? game.user.targets.first();
    let targetedActor = await game.actors.get(targetedToken.actor?.id ?? targetedToken.document?.actorId);
    let controlledToken = canvas.tokens.get(getProperty(item, `flags.${CONSTANTS.MODULE_ID}.controlId`)) ?? canvas.tokens.controlled[0];
    if (!validateAction(controlledToken, targetedToken, item.name)) {
      return false;
    }
    let result = roll;
    let harvesterMessage = "";
    let successArr = [];
    let messageData2 = { content: "", whisper: {} };
    if (SETTINGS.gmOnly) {
      messageData2.whisper = game.users.filter((u) => u.isGM).map((u) => u._id);
    }
    let matchedItems = [];
    harvesterAndLootingSocket.executeAsGM(addEffect, targetedToken.id, harvestAction.name);
    if (SETTINGS.enableBetterRollIntegration && hasBetterRollTables && item.name === harvestAction.name) {
      matchedItems = await _HarvestingHelpers.retrieveItemsHarvestWithBetterRollTables(
        targetedActor,
        item.name,
        result.total,
        getProperty(item, `flags.${CONSTANTS.MODULE_ID}.skillCheck`)
      );
      matchedItems.forEach((item2) => {
        if (item2.type === "loot") {
          harvesterMessage += `<li>@UUID[${item2.uuid}]</li>`;
          successArr.push(item2);
        }
      });
    } else {
      matchedItems = await searchCompendium(targetedActor, item.name);
      if (matchedItems[0].compendium.metadata.id === CONSTANTS.customCompendiumId) {
        matchedItems = matchedItems[0].items;
      }
      matchedItems.forEach((item2) => {
        if (item2.type === "loot") {
          let itemDC = 0;
          if (item2.compendium.metadata.id === CONSTANTS.harvestCompendiumId) {
            itemDC = parseInt(item2.system.description.chat);
          } else {
            itemDC = retrieveItemSourceLabelDC(item2);
          }
          if (itemDC <= result.total) {
            harvesterMessage += `<li>@UUID[${item2.uuid}]</li>`;
            successArr.push(item2.toObject());
          }
        }
      });
    }
    if (SETTINGS.autoAddItems && successArr?.length > 0) {
      if (SETTINGS.autoAddItemPiles && game.modules.get("item-piles")?.active) {
        await addItemsToActorWithItemPiles(controlledToken.actor, successArr);
      } else {
        await addItemsToActor(controlledToken.actor, successArr);
      }
    } else {
      harvesterMessage = `After examining the corpse you realise there is nothing you can harvest.`;
    }
    if (harvesterMessage) {
      messageData2.content = `<h3>Harvesting</h3><ul>${harvesterMessage}</ul>`;
    }
    ChatMessage.create(messageData2);
    return false;
  }
  static retrieveTablesHarvestWithBetterRollTables(targetedActor, actionName) {
    let actorName2 = targetedActor.name;
    if (actorName2.includes("Dragon")) {
      actorName2 = formatDragon(actorName2);
    }
    if (actionName === harvestAction.name) {
      const sourceValue = actorName2 ?? "";
      const docs = harvestBetterRollCompendium;
      let tablesChecked = [];
      for (const doc2 of docs) {
        if (sourceValue.trim() === getProperty(doc2, `flags.better-rolltables.brt-source-value`)?.trim()) {
          tablesChecked.push(doc2);
        }
      }
      if (!tablesChecked || tablesChecked.length === 0) {
        tablesChecked = game.tables.contents.filter((doc2) => {
          return sourceValue.trim() === getProperty(doc2, `flags.better-rolltables.brt-source-value`)?.trim();
        });
      }
      if (!tablesChecked || tablesChecked.length === 0) {
        Logger.warn(`No rolltable found for metadata sourceId '${sourceValue}'`, true);
        return [];
      }
      return tablesChecked;
    } else {
      return [];
    }
  }
  static async retrieveItemsHarvestWithBetterRollTables(targetedActor, actionName, dcValue = null, skillDenom = null) {
    let returnArr2 = [];
    if (actionName === harvestAction.name) {
      if (!dcValue) {
        dcValue = 0;
      }
      if (!skillDenom) {
        skillDenom = "";
      }
      const tablesChecked = _HarvestingHelpers.retrieveTablesHarvestWithBetterRollTables(targetedActor, actionName);
      if (!tablesChecked || tablesChecked.length === 0) {
        return [];
      }
      const tableHarvester = tablesChecked[0];
      returnArr2 = await game.modules.get("better-rolltables").api.retrieveItemsDataFromRollTableResultSpecialHarvester({
        table: tableHarvester,
        options: {
          rollMode: "gmroll",
          dc: dcValue,
          skill: skillDenom
        }
      });
    } else if (actionName === lootAction.name && !SETTINGS.disableLoot) {
      returnArr2 = checkCompendium(customLootCompendium, "name", actor.name);
      if (returnArr2.length !== 0) {
        return returnArr2;
      }
      returnArr2 = checkCompendium(lootCompendium, "name", actorName);
    }
    return returnArr2 ?? [];
  }
};
__name(_HarvestingHelpers, "HarvestingHelpers");
let HarvestingHelpers = _HarvestingHelpers;
const _LootingHelpers = class _LootingHelpers {
  static async handlePreRollLootAction(options) {
    const { item } = options;
    if (!checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
      return;
    }
    let targetedToken = canvas.tokens.get(getProperty(item, `flags.${CONSTANTS.MODULE_ID}.targetId`)) ?? game.user.targets.first();
    let targetedActor = game.actors.get(targetedToken.actor?.id ?? targetedToken.document?.actorId);
    let controlledToken = canvas.tokens.get(getProperty(item, `flags.${CONSTANTS.MODULE_ID}.controlId`)) ?? canvas.tokens.controlled[0];
    let controlActor = game.actors.get(controlledToken.actor?.id ?? controlledToken.document?.actorId);
    let matchedItems = [];
    if (SETTINGS.enableBetterRollIntegration && hasBetterRollTables) {
      matchedItems = searchCompendium(targetedActor, lootAction.name || item.name);
    } else {
      matchedItems = searchCompendium(targetedActor, lootAction.name || item.name);
    }
    if (matchedItems.length === 0) {
      RequestorHelpers.requestEmptyMessage(controlledToken.actor, void 0, {
        chatTitle: "Looting valuable from corpses.",
        chatDescription: `<h3>Looting</h3><ul>'${controlledToken.name}' attempted to loot resources from '${targetedToken.name}' but failed to find anything for this creature.`,
        chatButtonLabel: void 0,
        chatWhisper: void 0,
        chatSpeaker: void 0,
        chatImg: "icons/skills/social/theft-pickpocket-bribery-brown.webp"
      });
    } else {
      let normalLoot = matchedItems[0].description;
      if (normalLoot === "false" && !SETTINGS.lootBeasts) {
        ChatMessage.create(messageData);
        return;
      }
      matchedItems[0].description = "";
      matchedItems[0].roll({ async: false }).then((result) => {
        let rollMap = _LootingHelpers.formatLootRoll(result.results[0].text);
        let lootMessage = "";
        currencyFlavors.forEach((currency) => {
          if (!rollMap.has(currency))
            return;
          let roll = new Roll(rollMap.get(currency));
          let rollResult = roll.roll({ async: false });
          lootMessage += `<li>${rollResult.total} ${currency}</li>`;
          if (SETTINGS.autoAddItems) {
            _LootingHelpers.updateActorCurrency(controlActor, currency, rollResult.total);
          }
        });
        let messageData2 = { content: "", whisper: {} };
        if (SETTINGS.gmOnly) {
          messageData2.whisper = game.users.filter((u) => u.isGM).map((u) => u._id);
        }
        messageData2.content = `<h3>Looting</h3>After examining the corpse you find:<ul>${lootMessage}</ul>`;
        ChatMessage.create(messageData2);
      });
    }
    item.setFlag(CONSTANTS.MODULE_ID, "targetId", "");
    harvesterAndLootingSocket.executeAsGM(addEffect, targetedToken.id, lootAction.name);
  }
  static async handlePostRollLootAction(options) {
    return false;
  }
  static formatLootRoll(result) {
    let rollTableResult = result.replace(/(\[\[\/r\s)?(\]\])?(\}$)?/g, "").split("}");
    let returnMap = /* @__PURE__ */ new Map();
    for (let i = 0; i < rollTableResult.length; i++) {
      let extractedRoll = rollTableResult[i].split("{");
      returnMap.set(extractedRoll[1], extractedRoll[0]);
    }
    return returnMap;
  }
  static updateActorCurrency(actor2, currencyLabel, toAdd) {
    let currencyRef = CONSTANTS.currencyMap.get(currencyLabel);
    let total = actor2.system.currency[currencyRef] + toAdd;
    actor2.update({
      system: {
        currency: {
          [currencyRef]: total
        }
      }
    });
    Logger.log(`Added ${toAdd} ${currencyLabel} to: ${actor2.name}`);
  }
};
__name(_LootingHelpers, "LootingHelpers");
let LootingHelpers = _LootingHelpers;
const API = {
  async handlePreRollHarvestAction(inAttributes) {
    if (typeof inAttributes !== "object") {
      throw new Logger.error("handlePreRollHarvestAction | inAttributes must be of type object");
    }
    await HarvestingHelpers.handlePreRollHarvestAction(inAttributes);
  },
  async handlePostRollHarvestAction(inAttributes) {
    if (typeof inAttributes !== "object") {
      throw new Logger.error("handlePreRollHarvestAction | inAttributes must be of type object");
    }
    await HarvestingHelpers.handlePostRollHarvestAction(inAttributes);
  },
  async handlePreRollLootAction(inAttributes) {
    if (typeof inAttributes !== "object") {
      throw new Logger.error("handlePreRollLootAction | inAttributes must be of type object");
    }
    await LootingHelpers.handlePreRollLootAction(inAttributes);
  },
  async handlePostRollLootAction(inAttributes) {
    if (typeof inAttributes !== "object") {
      throw new Logger.error("handlePreRollLootAction | inAttributes must be of type object");
    }
    await LootingHelpers.handlePostRollLootAction(inAttributes);
  }
};
let actionCompendium;
let harvestCompendium;
let lootCompendium;
let customCompendium;
let customLootCompendium;
let harvestBetterRollCompendium;
let harvestAction;
let lootAction;
let harvesterAndLootingSocket;
let currencyFlavors;
let hasBetterRollTables;
Hooks.on("init", function() {
  registerSettings();
  Logger.log("Init() - Registered settings & Fetched compendiums.");
});
Hooks.once("setup", function() {
  game.modules.get(CONSTANTS.MODULE_ID).api = API;
});
Hooks.on("ready", async function() {
  actionCompendium = await game.packs.get(CONSTANTS.actionCompendiumId).getDocuments();
  harvestCompendium = await game.packs.get(CONSTANTS.harvestCompendiumId).getDocuments();
  lootCompendium = await game.packs.get(CONSTANTS.lootCompendiumId).getDocuments();
  customCompendium = await game.packs.get(CONSTANTS.customCompendiumId).getDocuments();
  customLootCompendium = await game.packs.get(CONSTANTS.customLootCompendiumId).getDocuments();
  hasBetterRollTables = await game.modules.get("better-rolltables")?.active;
  if (SETTINGS.enableBetterRollIntegration && hasBetterRollTables) {
    harvestBetterRollCompendium = await game.packs.get(CONSTANTS.betterRollTableId).getDocuments();
  }
  harvestAction = await actionCompendium.find((a) => a.id === CONSTANTS.harvestActionId);
  lootAction = await actionCompendium.find((a) => a.id === CONSTANTS.lootActionId);
  currencyFlavors = Array.from(CONSTANTS.currencyMap.keys());
  if (game.user?.isGM && !game.modules.get("socketlib")?.active)
    Logger.errorPermanent("socketlib must be installed & enabled for harvester to function correctly.", {
      permanent: true
    });
  if (game.users.activeGM?.id !== game.user.id) {
    return;
  }
  await addActionToActors();
});
Hooks.once("socketlib.ready", () => {
  harvesterAndLootingSocket = globalThis.socketlib.registerModule(CONSTANTS.MODULE_ID);
  harvesterAndLootingSocket.register("addEffect", addEffect);
  Logger.log("Registered socketlib functions");
});
Hooks.on("createActor", async (actor2, data, options, id) => {
  if (SETTINGS.autoAddActionGroup !== "None") {
    if (SETTINGS.autoAddActionGroup === "PCOnly" && actor2.type === "npc") {
      return;
    }
    await addItemsToActor(actor2, [harvestAction]);
    if (!SETTINGS.disableLoot) {
      await addItemsToActor(actor2, [lootAction]);
    }
  }
});
Hooks.on("dnd5e.preUseItem", function(item, config, options) {
  if (!checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
    return;
  }
  if (game.user.targets.size !== 1) {
    Logger.warn("Please target only one token.", true);
    return false;
  }
  let targetedToken = game.user.targets.first();
  let controlToken = item.parent.getActiveTokens()[0];
  if (!validateAction(controlToken, targetedToken, item.name)) {
    return false;
  }
  item.setFlag(CONSTANTS.MODULE_ID, "targetId", targetedToken.id);
  item.setFlag(CONSTANTS.MODULE_ID, "controlId", controlToken.id);
});
Hooks.on("dnd5e.useItem", function(item, config, options) {
  if (!checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
    return;
  }
  if (item.name === harvestAction.name) {
    HarvestingHelpers.handlePreRollHarvestAction({ item });
  }
  if (item.name === lootAction.name && !SETTINGS.disableLoot) {
    LootingHelpers.handlePreRollLootAction({ item });
  }
});
Hooks.on("dnd5e.preDisplayCard", function(item, chatData, options) {
  if (checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
    options.createMessage = false;
  }
});
function validateAction(controlToken, targetedToken, actionName) {
  let measuredDistance = canvas.grid.measureDistance(controlToken.center, targetedToken.center);
  let targetSize = CONSTANTS.sizeHashMap.get(targetedToken.actor.system.traits.size);
  if (measuredDistance > targetSize && SETTINGS.enforceRange) {
    Logger.warn("You must be in range to " + actionName, true);
    return false;
  }
  let actor2 = null;
  if (!isEmptyObject(targetedToken.document.delta?.system)) {
    actor2 = targetedToken.document.delta;
  } else if (!isEmptyObject(targetedToken.document.actor)) {
    actor2 = targetedToken.document.actor;
  } else if (targetedToken.document?.actorId) {
    actor2 = game.actors.get(targetedToken.actor?.id ?? targetedToken.document?.actorId);
  } else if (targetedToken.actor?.id) {
    actor2 = game.actors.get(targetedToken.actor?.id ?? targetedToken.document?.actorId);
  }
  if (!actor2) {
    Logger.warn(targetedToken.name + " has not data to retrieve", true);
    return false;
  }
  if (actor2.system.attributes.hp.value !== 0) {
    Logger.warn(targetedToken.name + " is not dead", true);
    return false;
  }
  if (!checkEffect(targetedToken, "Dead") && SETTINGS.requireDeadEffect) {
    Logger.warn(targetedToken.name + " is not dead", true);
    return false;
  }
  if (targetedToken.document.hasPlayerOwner && SETTINGS.npcOnlyHarvest) {
    Logger.warn(targetedToken.name + " is not an NPC", true);
    return false;
  }
  if (checkEffect(targetedToken, `${actionName}ed`)) {
    Logger.warn(`${targetedToken.name} has been ${actionName.toLowerCase()}ed already`, true);
    return false;
  }
  return true;
}
__name(validateAction, "validateAction");
function searchCompendium(actor2, actionName) {
  let returnArr2 = [];
  let actorName2 = actor2.name;
  if (actorName2.includes("Dragon")) {
    actorName2 = formatDragon$1(actorName2);
  }
  if (actionName === harvestAction.name) {
    returnArr2 = checkCompendium$1(customCompendium, "name", actor2.name);
    if (returnArr2.length !== 0)
      return returnArr2;
    returnArr2 = checkCompendium$1(harvestCompendium, "system.source.label", actorName2);
  } else if (actionName === lootAction.name && !SETTINGS.disableLoot) {
    returnArr2 = checkCompendium$1(customLootCompendium, "name", actor2.name);
    if (returnArr2.length !== 0) {
      return returnArr2;
    }
    returnArr2 = checkCompendium$1(lootCompendium, "name", actorName2);
  }
  return returnArr2;
}
__name(searchCompendium, "searchCompendium");
function checkCompendium$1(compendium, checkProperty, matchProperty) {
  let returnArr = [];
  compendium.forEach((doc) => {
    if (eval(`doc.${checkProperty}`) === matchProperty) {
      returnArr.push(doc);
    }
  });
  return returnArr;
}
__name(checkCompendium$1, "checkCompendium$1");
async function addActionToActors() {
  if (SETTINGS.autoAddActionGroup === "None") {
    return;
  }
  game.actors.forEach(async (actor2) => {
    if (SETTINGS.autoAddActionGroup === "PCOnly" && actor2.type === "npc") {
      return;
    }
    let hasHarvest = false;
    let hasLoot = false;
    actor2.items.forEach((item) => {
      if (item.name === harvestAction.name && checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
        hasHarvest = true;
        resetToDefault(item);
      }
      if (item.name === lootAction.name && checkItemSourceLabel(item, CONSTANTS.SOURCE_REFERENCE_MODULE)) {
        hasLoot = true;
        resetToDefault(item);
        if (SETTINGS.disableLoot) {
          actor2.deleteEmbeddedDocuments("Item", [item.id]);
        }
      }
    });
    if (!hasHarvest) {
      await addItemsToActor(actor2, [harvestAction]);
    }
    if (!hasLoot && !SETTINGS.disableLoot) {
      await addItemsToActor(actor2, [lootAction]);
    }
  });
  Logger.log("harvester | ready() - Added Actions to All Actors specified in Settings");
}
__name(addActionToActors, "addActionToActors");
function checkEffect(token2, effectName) {
  let returnBool = false;
  token2.document.delta?.effects?.forEach((element) => {
    if (element.name === effectName)
      returnBool = true;
  });
  return returnBool;
}
__name(checkEffect, "checkEffect");
function formatDragon$1(actorName2) {
  let actorSplit = actorName2.split(" ");
  CONSTANTS.dragonIgnoreArr.forEach((element) => {
    actorSplit = actorSplit.filter((e) => e !== element);
  });
  actorSplit = actorSplit.join(" ");
  return actorSplit;
}
__name(formatDragon$1, "formatDragon$1");
function resetToDefault(item) {
  let actionDescription = `Harvest valuable materials from corpses.`;
  if (item.name === lootAction.name)
    actionDescription = `Scavenge valuables from corpses.`;
  item.update({
    flags: { harvester: { targetId: "", controlId: "" } },
    system: { formula: "", description: { value: actionDescription } }
  });
}
__name(resetToDefault, "resetToDefault");
function addEffect(targetTokenId, actionName) {
  let targetToken = canvas.tokens.get(targetTokenId);
  if (actionName === harvestAction.name) {
    targetToken.document.toggleActiveEffect(
      {
        id: CONSTANTS.harvestActionEffectId,
        icon: CONSTANTS.harvestActionEffectIcon,
        name: CONSTANTS.harvestActionEffectName
      },
      { active: true }
    );
  } else if (actionName === lootAction.name && !SETTINGS.disableLoot) {
    targetToken.document.toggleActiveEffect(
      { id: CONSTANTS.lootActionEffectId, icon: CONSTANTS.lootActionEffectIcon, name: CONSTANTS.lootActionEffectName },
      { active: true }
    );
  }
  Logger.log(`Added ${actionName.toLowerCase()}ed effect to: ${targetToken.name}`);
}
__name(addEffect, "addEffect");
async function addItemsToActor(actor2, itemsToAdd) {
  for (const item of itemsToAdd) {
    await _createItem(item, actor2);
  }
}
__name(addItemsToActor, "addItemsToActor");
async function addItemsToActorWithItemPiles(targetedToken, itemsToAdd) {
  game.itempiles.API.addItems(targetedToken, itemsToAdd, {
    mergeSimilarItems: true
  });
  Logger.log(`Added ${itemsToAdd.length} items to ${targetedToken.name}`);
}
__name(addItemsToActorWithItemPiles, "addItemsToActorWithItemPiles");
function isEmptyObject(obj) {
  if (obj === null || obj === void 0) {
    return true;
  }
  if (isRealNumber(obj)) {
    return false;
  }
  const result = obj && // null and undefined check
  Object.keys(obj).length === 0;
  return result;
}
__name(isEmptyObject, "isEmptyObject");
function isRealNumber(inNumber) {
  return !isNaN(inNumber) && typeof inNumber === "number" && isFinite(inNumber);
}
__name(isRealNumber, "isRealNumber");
async function _createItem(item, actor2, stackSame = true, customLimit = 0) {
  const QUANTITY_PROPERTY_PATH = "system.quantity";
  const WEIGHT_PROPERTY_PATH = "system.weight";
  const PRICE_PROPERTY_PATH = "system.price";
  const newItemData = item;
  getProperty(newItemData, PRICE_PROPERTY_PATH) || 0;
  const embeddedItems = [...actor2.getEmbeddedCollection("Item").values()];
  const originalItem = embeddedItems.find((i) => i.name === newItemData.name);
  if (originalItem && stackSame) {
    const stackAttribute = QUANTITY_PROPERTY_PATH;
    const priceAttribute = PRICE_PROPERTY_PATH;
    const weightAttribute = WEIGHT_PROPERTY_PATH;
    const newItemQty = getProperty(newItemData, stackAttribute) || 1;
    const originalQty = getProperty(originalItem, stackAttribute) || 1;
    const updateItem = { _id: originalItem.id };
    const newQty = Number(originalQty) + Number(newItemQty);
    if (customLimit > 0) {
      if (Number(customLimit) < Number(newQty)) {
        Logger.warn("Custom limit is been reached for the item '" + item.name + "'", true);
        return customLimit;
      }
    }
    if (newQty !== newItemQty) {
      setProperty(updateItem, stackAttribute, newQty);
      const newPriceValue = (getProperty(originalItem, priceAttribute)?.value ?? 0) + (getProperty(newItemData, priceAttribute)?.value ?? 0);
      const newPrice = {
        denomination: getProperty(item, priceAttribute)?.denomination,
        value: newPriceValue
      };
      setProperty(updateItem, `${priceAttribute}`, newPrice);
      const newWeight = (getProperty(originalItem, weightAttribute) ?? 1) + (getProperty(newItemData, weightAttribute) ?? 1);
      setProperty(updateItem, `${weightAttribute}`, newWeight);
      await actor2.updateEmbeddedDocuments("Item", [updateItem]);
      Logger.log(`Updated ${item.name} to ${actor2.name}`);
    } else {
      Logger.log(`Nothing is done with ${item.name} on ${actor2.name}`);
    }
  } else {
    await actor2.createEmbeddedDocuments("Item", [newItemData]);
    Logger.log(`Added ${item.name} to ${actor2.name}`);
  }
}
__name(_createItem, "_createItem");
export {
  actionCompendium,
  addEffect,
  addItemsToActor,
  addItemsToActorWithItemPiles,
  checkCompendium$1 as checkCompendium,
  currencyFlavors,
  customCompendium,
  customLootCompendium,
  harvestAction,
  harvestBetterRollCompendium,
  harvestCompendium,
  harvesterAndLootingSocket,
  hasBetterRollTables,
  lootAction,
  lootCompendium,
  searchCompendium,
  validateAction
};
//# sourceMappingURL=module.js.map
